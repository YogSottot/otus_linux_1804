#!/usr/bin/env python
# -*- coding: utf-8 -*-
import ConfigParser
import os
import time

import ftputil

import server.backup.Static.files.Main
#import server.backup.Static.mysql.Main
import server.config.Config


class BackUp:
    filestamp = time.strftime('%Y-%m-%d-%I:%M')

    def __init__(self):
        pass

    def send_cloud(self):
        config = server.config.Config.Config()
        sconfig = config.getConfig()
        # Отправляем
        ftp_host = ftputil.FTPHost(sconfig['cloud']["ftp"], sconfig['cloud']["login"], sconfig['cloud']["password"])
        ftp_host.mkdir(sconfig['cloud']['dir'] + self.filestamp)
        for path_file in config.get_files_to_send():
            #print(path_file)
            ftp_host.upload_if_newer(path_file,
                                 sconfig['cloud']['dir'] + '/' + self.filestamp + '/' + path_file)
            rm_path = sconfig['server']['path']+path_file
            os.remove(rm_path)

    def start(self):
        #m = server.backup.Static.mysql.Main.BackUp()
        #m.mysql_backup()
        f = server.backup.Static.files.Main.BackUp()
        f.file_backup()
        # q = server.config.Config.Config()
        # print (q.get_files_to_send())
        self.send_cloud()
