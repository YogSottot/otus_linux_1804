#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ConfigParser, os, ftputil, tarfile, time


class Config:
    files_to_send = []

    def __init__(self):
        pass

    def getConfig(self):
        filestamp = time.strftime('%Y-%m-%d-%I:%M')

        config = ConfigParser.RawConfigParser()
        config.read('config.ini')

        mysqlConf = {
            'host': config.get('mysql', 'host'),
            'password': config.get('mysql', 'password'),
            'user': config.get('mysql', 'user'),
            'database': config.get('mysql', 'database')
        }

        cloudConf = {
            'login': config.get('cloud', 'login'),
            'password': config.get('cloud', 'password'),
            'ftp': config.get('cloud', 'ftp'),
            'dir': config.get('cloud', 'dir'),
            'days': config.getint('cloud', 'days')
        }

        fileConf = {
            'dir': list(filter(None, (x.strip() for x in config.get('file', 'dir').splitlines()))),
            'exclude': list(filter(None, (x.strip() for x in config.get('file', 'exclude').splitlines())))
        }

        serverConf = {
            'name': config.get('server', 'name'),
                      'path': config.get('server', 'path')
        }

        return dict([
            ('mysql', mysqlConf),
            ('cloud', cloudConf),
            ('server', serverConf),
            ('files', fileConf),
        ])

    def set_files_to_send(self, value):
        self.files_to_send.append(value)

    def get_files_to_send(self):
        return self.files_to_send
