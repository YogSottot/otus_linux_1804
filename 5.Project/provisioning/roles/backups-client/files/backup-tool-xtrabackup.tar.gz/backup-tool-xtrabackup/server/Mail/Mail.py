#!/usr/bin/env python
# -*- coding: utf-8 -*-

import server.config.Config
import time, smtplib
from email.mime.text import MIMEText

class CMail:
    filestamp = time.strftime('%Y-%m-%d-%H:%M')
    config = server.config.Config.Config()
    sconfig = config.getConfig()

    def __init__(self):
        pass

    def send(self, message):
        msg = MIMEText(message)
        msg['Subject'] = 'BackUp server %s' % self.sconfig['server']['name']
        msg['From'] = self.sconfig['mail']['login']
        msg['To'] = self.sconfig['mail']['to']
        s = smtplib.SMTP(self.sconfig['mail']['server'], self.sconfig['mail']['port'])
        s.starttls()
        s.login(self.sconfig['mail']['login'], self.sconfig['mail']['pass'])
        s.sendmail(self.sconfig['mail']['login'], self.sconfig['mail']['to'], msg.as_string())
        s.quit()
