#!/usr/bin/env python
# -*- coding: utf-8 -*-

import psutil
class CCpu:

    def __init__(self):
        pass


    def get(self):
        cpu_times = self.cpu_times()


    def cpu_times(self):
        return psutil.cpu_times()

