#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse

from server.backup.Static import Backup

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--type', metavar=u'Тип бекапа', type=str, dest='type_b',
         help='Type Backup')
    # parser.add_argument(
    #     '--sum', dest='accumulate', action='store_const', const=sum,
    #     default=max, help='sum the integers (default: find the max)')
    #
    args = parser.parse_args()
    print('type='+args.type_b)
    if args.type_b == "static":
        q = Backup.BackUp()
        q.start()
