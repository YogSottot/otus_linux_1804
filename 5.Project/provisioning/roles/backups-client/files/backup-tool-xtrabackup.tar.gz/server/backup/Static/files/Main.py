#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ConfigParser, os, ftputil, tarfile, time
import server.config.Config

class BackUp:
    filestamp = time.strftime('%Y-%m-%d-%I:%M')

    def filter_function(self, filename):
        config = server.config.Config.Config()
        sconfig = config.getConfig()
        exclude_dir = sconfig['files']['exclude']
        result = None
        for fileEx in exclude_dir:
            if fileEx in filename.name:
                result = None
                break
            else:
                result = filename
        return result




    def file_backup(self):
        config = server.config.Config.Config()
        sconfig = config.getConfig()
        for dirs in sconfig['files']['dir']:
            tar_name =  dirs.replace('/', '_') + '_' + self.filestamp +'.tar.gz'
            tar = tarfile.open(tar_name, "w:gz")
            tar.add(dirs, filter=self.filter_function)
            tar.close()
            config.set_files_to_send(tar_name)