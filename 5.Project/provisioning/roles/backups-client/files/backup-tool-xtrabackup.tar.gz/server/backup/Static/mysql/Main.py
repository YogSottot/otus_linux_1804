#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os, time
import server.config.Config


class BackUp:
    filestamp = time.strftime('%Y-%m-%d-%I:%M')

    # config = ConfigParser.RawConfigParser()
    # config.read('config.ini')
    # mysqlConf = {'host': config.get('mysql', 'host'),
    #              'password': config.get('mysql', 'password'),
    #              'user': config.get('mysql', 'user'),
    #              'database': config.get('mysql', 'database')}
    #
    # cloudConf = {'login': config.get('cloud', 'login'),
    #              'password': config.get('cloud', 'password'),
    #              'ftp': config.get('cloud', 'ftp'),
    #              'dir': config.get('cloud', 'dir')}
    #
    # nameConf = config.get('server', 'name')
    #
    # fileConf = {'dir': list(filter(None, (x.strip() for x in config.get('file', 'dir').splitlines()))),
    #            'exclude': list(filter(None, (x.strip() for x in config.get('file', 'exclude').splitlines())))}
    #
    # serverConf = {'name': config.get('server', 'name'),
    #           'path': config.get('server', 'path')}
    #
    # files_to_send = []

    def __init__(self):
        pass

    def mysql_backup(self):
        config = server.config.Config.Config()
        sconfig = config.getConfig()
        #print(sconfig)
        # Делаем бекап
        file_backup_full = sconfig['server']['path'] + sconfig['mysql']['database'] + "_" + self.filestamp + '.xbstream'
        file_backup = sconfig['mysql']['database'] + "_" + self.filestamp + '.xbstream'
        if (len(sconfig['mysql']['password']) > 0):
            os.popen("mysqldump -u %s -p%s -h %s -e --opt --single-transaction --quick -B %s | gzip -c > %s" % (
                sconfig['mysql']['user'], sconfig['mysql']['password'],
                sconfig['mysql']['host'], sconfig['mysql']['database'],
                file_backup))
        else:
            os.popen("xtrabackup --backup --stream=xbstream --compress --tmp-dir=/tmp > %s" % (
                  file_backup))

            config.set_files_to_send(file_backup)
