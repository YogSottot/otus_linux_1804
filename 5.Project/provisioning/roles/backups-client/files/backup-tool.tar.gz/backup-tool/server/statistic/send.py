#!/usr/bin/env python
# -*- coding: utf-8 -*-


class CSend:

    def __init__(self):
        pass

    def connect(self):
        pass

